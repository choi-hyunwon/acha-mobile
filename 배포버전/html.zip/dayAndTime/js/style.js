
const amPmEl = document.querySelector('.amPm')
const hourEl = document.querySelector('.hour')
const minuteEl = document.querySelector('.minute')
const secondEl = document.querySelector('.second')

const yearEl = document.querySelector('.year')
const monthEl = document.querySelector('.month')
const dayEl = document.querySelector('.day')
const weekEl = document.querySelector('.dayWeek')

init()

function init() {    
    getTime()
    getDays()
    setInterval( getTime, 1000);
}

function getDate() {
    today = new Date(); 
}

// 시간
function getTime() {
    getDate();
    let hour = today.getHours();
    let minute = today.getMinutes();
    let second = today.getSeconds();

    amPmEl.innerHTML = hour < 12 ? '오전' : '오후';
    hourEl.innerHTML = hour;
    minuteEl.innerHTML = minute < 10 ? `0${minute}`: minute;
    secondEl.innerHTML = second < 10 ? `0${second}` : second;    
}

// 날짜
function getDays() {
    getDate();

    const weekend = ['일','월', '화', '수', '목', '금','토']

    let yyyy = today.getFullYear();
    let mm = today.getMonth() + 1;
    let dd = today.getDate();
    let week = today.getDay();

    yearEl.innerHTML =  yyyy;
    monthEl.innerHTML = mm;
    dayEl.innerHTML = dd;
    weekEl.innerHTML = weekend[week] + '요일';
    

}


