import React, { useEffect, useState, useRef } from "react";
const rspCoord = {
  바위: "0",
  가위: "-142px",
  보: "-284px",
};

const scores = {
  가위: 1,
  바위: 0,
  보: -1,
};

const computerChoice = (imgCoord) => {
  return Object.entries(rspCoord).find(function (v) {
    return v[1] === imgCoord;
  })[0];
};

const RSP = () => {
  const [result, setResult] = useState("");
  const [imgCoord, setImgCoord] = useState(rspCoord.바위);
  const [score, setScore] = useState(0);
  const interval = useRef();

  useEffect(() => {
    interval.current = setInterval(changeHand, 1000);
    return () => {
      clearInterval(interval.current);
    };
  }, [imgCoord]);

  const changeHand = () => {
    if (imgCoord === rspCoord.바위) {
      setImgCoord(rspCoord.가위);
    } else if (imgCoord === rspCoord.가위) {
      setImgCoord(rspCoord.보);
    } else if (imgCoord === rspCoord.보) {
      setImgCoord(rspCoord.바위);
    }
  };

  const onClickBtn = (choice) => () => {
    //   나의 선택과 컴퓨터의 선택을 감지

    clearInterval(interval.current);
    const myChoice = scores[choice];
    const cpuChoice = scores[computerChoice(imgCoord)];
    const diff = myChoice - cpuChoice;

    if (diff === 0) {
      setResult("비겼습니다.");
    } else if ([-1, 2].includes(diff)) {
      setResult("이겼습니다.");
      setScore(score + 1);
    } else {
      setResult("졌습니다.");
      setScore(score - 1);
    }

    setTimeout(() => {
      interval.current = setInterval(changeHand, 1000);
    }, 1500);
  };

  return (
    <>
      <div
        id="computer"
        style={{
          background: `url(https://en.pimg.jp/023/182/267/1/23182267.jpg) ${imgCoord} 0`,
        }}
      />
      <div>
        <button id="scissors" className="btn" onClick={onClickBtn("가위")}>
          가위
        </button>
        <button id="rock" className="btn" onClick={onClickBtn("바위")}>
          바위
        </button>
        <button id="rock" className="btn" onClick={onClickBtn("보")}>
          보
        </button>
      </div>
      <div>{result}</div>
      <div>현재 점수 : {score}</div>
    </>
  );
};
export default RSP;
