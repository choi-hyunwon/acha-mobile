import React, { memo } from "react";

const Ball = memo(({ numbers }) => {
  //   const { numbers } = this.props;
  let background;
  if (numbers <= 10) {
    background = "red";
  } else if (numbers <= 20) {
    background = "orange";
  } else if (numbers <= 30) {
    background = "pink";
  } else if (numbers <= 40) {
    background = "blue";
  } else {
    background = "green";
  }

  return (
    <>
      <div className="ball" style={{ background }}>
        {numbers}
      </div>
    </>
  );
});

export default Ball;
