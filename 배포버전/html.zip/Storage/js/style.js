window.onload = function () {
    let myName = document.querySelector('.myNickName .name')
    let value = sessionStorage.getItem('nickName')

    myName.innerHTML = value
}


const btn = document.querySelector('button')

btn.addEventListener('click', function () {
    window.history.back();
    
    sessionStorage.removeItem('nickName')
})
