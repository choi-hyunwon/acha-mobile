const inputEl = document.querySelector(".todo-input");
const unCompleteEl = document.querySelector(".unComplete-list");
const completeEl = document.querySelector(".complete-list");

let todos = [];
let id = "";

const setTodos = (newTodos) => {
  return (todos = newTodos);
};

const getAllTodos = () => {
  return todos;
};

const addTodos = (text) => {
  const newId = id++;
  newTodos = [
    ...getAllTodos(),
    { id: newId, isComplete: false, content: text },
  ];
  setTodos(newTodos);
  paintList();
};

let isCompletet;
// 완료 클릭 이벤트
const completeTodo = (todoId) => {
  const newTodos = getAllTodos().map((todo) =>
    todo.id === todoId ? { ...todo, isComplete: !todo.isComplete } : todo
  );

  setTodos(newTodos);
  paintList();
};

// 화면에 그리는 함수
const paintList = () => {
  unCompleteEl.innerHTML = ""; // 리스트 초기화
  completeEl.innerHTML = "";
  const allTodos = getAllTodos();

  allTodos.map((todo) => {
    const todoItemEl = document.createElement("li");
    todoItemEl.classList.add("todo-item");

    const checkBoxEl = document.createElement("div");
    checkBoxEl.classList.add("checkbox");
    checkBoxEl.addEventListener("click", () => completeTodo(todo.id));

    const todoEl = document.createElement("div");
    todoEl.classList.add("todo");
    todoEl.innerText = todo.content;

    const delBtnEl = document.createElement("button");
    delBtnEl.classList.add("delBtn");
    delBtnEl.innerHTML = "X";

    todoItemEl.appendChild(checkBoxEl);
    todoItemEl.appendChild(todoEl);
    todoItemEl.appendChild(delBtnEl);

    if (todo.isComplete === true) {
      todoItemEl.classList.add("checked");
      checkBoxEl.innerHTML = "✔";

      completeEl.appendChild(todoItemEl);
    } else {
      unCompleteEl.appendChild(todoItemEl);
    }
  });
  console.log(allTodos);
};

const init = () => {
  inputEl.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      let value = e.target.value;
      addTodos(value);
      e.target.value = "";
    }
  });
};

init();
