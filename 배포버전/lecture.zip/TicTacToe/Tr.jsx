import React from 'react'
import Td from './Td'

const Tr = ({ rowData, rowIndex, dispatch, }) => {
  return (
    <tr>
      {
        Array(rowData.length).fill().map((td, idx) => <Td key={idx} dispatch={dispatch} rowIndex={rowIndex} cellIndex={idx} cellData={rowData[idx]} > {''} </Td>)
      }
    </tr >
  )
}

export default Tr