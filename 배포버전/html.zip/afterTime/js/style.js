const newTime = document.querySelector('.nowTime')
const beforeTime = document.querySelector('.beforeTime')
const textInput = document.querySelector('input')

textInput.addEventListener('change', function () {
    setTime()
})

function setTime() {
    let time = new Date();

    setInterval(() => {
        beforeTime.innerHTML = elTime(time);
    }, 1000);   
}

const elTime = (time) => {    
    const start = new Date(time);
    const end = new Date();

    const second = Math.floor((end.getTime() - start.getTime()) / 1000)
    if (second < 60) return "방금전";

    const minute = second / 60
    if (minute < 60) return `${Math.floor(minute)}분 전`;

    const hour = minute / 24
    if (hour < 60) return `${Math.floor(hour)}시간 전`;

    const days = hour / 24
    if (hour < 60) return `${Math.floor(days)}일 전`;
  
    
}
