const todoInputEl = document.querySelector(".todo-input");
const todoListEl = document.querySelector(".todo-list");
const completeAllBtnEl = document.querySelector(".complete-all-btn");
const leftItemsEl = document.querySelector(".left-items");

const showAllBtnEl = document.querySelector(".show-all-btn");
const showActiveBtnEl = document.querySelector(".show-active-btn");
const showCompleteBtnEl = document.querySelector(".show-completed-btn");
const clearCompletedBtnEl = document.querySelector(".clear-completed-btn");

let todos = [];
let id = [];

const getAllTodos = () => {
  return todos;
};

const getActiveTodos = () => {
  return todos.filter((todo) => todo.isCompleted === false);
};

const getCompleteTodos = () => {
  return todos.filter((todo) => todo.isCompleted === true);
};

const setLeftItems = () => {
  const leftTodos = getActiveTodos();
  leftItemsEl.innerHTML = `${leftTodos.length} items left`;
};

// newTodos를 todo에 설정
const setTodos = (newTodos) => {
  todos = newTodos;
};

// input.value 를 todos에 추가하기
const appendTodos = (text) => {
  const newID = id++;
  const newTodos = [
    ...getAllTodos(),
    { id: newID, isCompleted: false, content: text },
  ];

  setTodos(newTodos);
  checkIsAllCompleted(); //전체 완료처리
  paintTodos();
  setLeftItems();
};

let isAllCompleted = false; // 전체 todos 체크 여부
const setIsAllCompleted = (bool) => (isAllCompleted = bool);
const completeAll = () => {
  completeAllBtnEl.classList.add("checked");
  const newTodos = getAllTodos().map((todos) => ({
    ...todos,
    isCompleted: true,
  }));
  setTodos(newTodos);
};
const incompleteAll = () => {
  completeAllBtnEl.classList.remove("checked");
  const newTodos = getAllTodos().map((todos) => ({
    ...todos,
    isCompleted: false,
  }));
  setTodos(newTodos);
};

// 전체 todos의 check 여부 확인
const checkIsAllCompleted = () => {
  if (getAllTodos().length === getCompleteTodos().length) {
    setIsAllCompleted(true);
    completeAllBtnEl.classList.add("checked");
  } else {
    setIsAllCompleted(false);
    completeAllBtnEl.classList.remove("checked");
  }
};

const deleteTodo = (todoId) => {
  // filter 해당 id가 같으면 빼고 배열을 다시 만들어 return
  const newTodos = getAllTodos().filter((todo) => todo.id !== todoId);
  setTodos(newTodos);
  paintTodos();
  setLeftItems();
};

// 각각의 li check 누를때
const completeTodo = (todoId) => {
  // todoId를 비교해서 isCompleted를 반환
  const newTodos = getAllTodos().map((todo) =>
    todo.id === todoId ? { ...todo, isCompleted: !todo.isCompleted } : todo
  );

  setTodos(newTodos);
  paintTodos();
  checkIsAllCompleted(); //전체 todos의 완료 상태를 파악하여 전체 완료 처리 버튼
  setLeftItems();
};

const updateTodo = (text, todoId) => {
  const newTodos = getAllTodos().map((todo) =>
    todo.id === todoId ? { ...todo, content: text } : todo
  );
  setTodos(newTodos);
  paintTodos();
  setLeftItems();
};

// 클릭된 btn active 하기
let currentShowType = "all";
const setCurrentShowType = (newType) => (currentShowType = newType);
const onClickShowTodosType = (e) => {
  const currentBtnEl = e.target;
  const newShowType = currentBtnEl.dataset.type;

  if (currentShowType === newShowType) return;

  const preBtnEl = document.querySelector(`.show-${currentShowType}-btn`);
  preBtnEl.classList.remove("selected");

  currentBtnEl.classList.add("selected");
  setCurrentShowType(newShowType);

  paintTodos();
};

// all active complete 구분
const paintTodos = () => {
  todoListEl.innerHTML = ""; //초기화

  switch (currentShowType) {
    case "all":
      const allTodos = getAllTodos();
      allTodos.forEach((todo) => {
        paintTodo(todo);
      });
      break;
    case "active":
      const activeTodos = getActiveTodos();
      activeTodos.forEach((todo) => {
        paintTodo(todo);
      });
      break;
    case "completed":
      const completedTodos = getCompleteTodos();
      completedTodos.forEach((todo) => {
        paintTodo(todo);
      });
      break;
    default:
      break;
  }
};

// 전체 completet 하기
const onClickCompleteAll = () => {
  if (!getAllTodos().length) return; //todos 배열의 길이가  0이면 return;

  if (isAllCompleted) incompleteAll();
  else completeAll();
  setIsAllCompleted(!isAllCompleted);
  paintTodos();
  setLeftItems();
};

// 화면에 리스크 그리기
const paintTodo = (todo) => {
  const todoItemEl = document.createElement("li");
  todoItemEl.classList.add("todo-item");

  const checkboxEl = document.createElement("div");
  checkboxEl.classList.add("checkbox");
  checkboxEl.addEventListener("click", () => completeTodo(todo.id));

  const todoEl = document.createElement("div");
  todoEl.classList.add("todo");
  todoEl.addEventListener("dblclick", (event) => ondblclick(event, todo.id));
  todoEl.innerText = todo.content;

  const delBtnEl = document.createElement("button");
  delBtnEl.classList.add("delBtn");
  delBtnEl.addEventListener("click", () => deleteTodo(todo.id));
  delBtnEl.innerHTML = "X";

  if (todo.isCompleted) {
    todoItemEl.classList.add("checked");
    checkboxEl.innerText = "✔";
  }

  todoItemEl.appendChild(checkboxEl);
  todoItemEl.appendChild(todoEl);
  todoItemEl.appendChild(delBtnEl);
  todoListEl.appendChild(todoItemEl);
};

// 더블클릭 수정
const ondblclick = (e, todoId) => {
  const todoEl = e.target;
  const inputText = todoEl.innerText;
  const todoItemEl = todoEl.parentNode;
  const inputEl = document.createElement("input");
  inputEl.value = inputText;
  inputEl.classList.add("edit-input");

  inputEl.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      updateTodo(e.target.value, todoId);
      document.body.removeEventListener("click", onClickBody);
    }
  });

  const onClickBody = (e) => {
    if (e.target !== inputEl) {
      todoItemEl.removeChild(inputEl);
      document.body.removeEventListener("click", onClickBody);
    }
  };

  todoItemEl.appendChild(inputEl);
  inputEl.focus();

  document.body.addEventListener("click", onClickBody);
};

const clearCompletedTodos = () => {
  const newTodos = getActiveTodos();
  setTodos(newTodos);
  paintTodo();
};

const init = () => {
  todoInputEl.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      appendTodos(e.target.value);
      todoInputEl.value = "";
    }
  });

  completeAllBtnEl.addEventListener("click", onClickCompleteAll);
  showAllBtnEl.addEventListener("click", onClickShowTodosType);
  showActiveBtnEl.addEventListener("click", onClickShowTodosType);
  showCompleteBtnEl.addEventListener("click", onClickShowTodosType);
  clearCompletedBtnEl.addEventListener("click", clearCompletedTodos);
  setLeftItems();
};

init();
