import React, { useContext, useCallback } from 'react'
import { CODE, TableContext, OPEN_CELL, CLICK_MINE, FLAG_CELL, QUESTION_CELL, NORMAL_CELL } from './MineSearch'

const getTdStyle = (code) => {
    switch (code) {
        case CODE.NORMAL:  //기본 어두운값
        case CODE.MINE: //기본 어두운값
            return {
                backgroundColor: '#444'
            }
        case CODE.CLICKED_MINE:
        case CODE.OPENED:  //클릭한해서 열었을 경우
            return {
                backgroundColor: '#fff'
            }
        case CODE.QUESTION:
        case CODE.QUESTION_MINE:
            return {
                backgroundColor: 'yellow'
            }
        case CODE.FLAG:
        case CODE.FLAG_MINE:
            return {
                backgroundColor: 'red'
            }
        default:
            return {
                backgroundColor: '#fff'
            }
    }
}
const getTdText = (code) => {
    switch (code) {
        case CODE.NORMAL:
            return ''
        case CODE.MINE: //디버깅을 위한 x넣기 실제 작업할때는 제거
            return 'X'
        case CODE.CLICKED_MINE:
            return '펑'
        case CODE.FLAG_MINE:
        case CODE.FLAG:
            return '!'
        case CODE.QUESTION_MINE:
        case CODE.QUESTION:
            return '?'
        default:
            return '';
    }
}

const Td = ({ rowIndex, cellIndex }) => {
    const { tableData, dispatch, hold } = useContext(TableContext)
    console.log(hold);

    const onClickTd = useCallback(() => {
        console.log(hold);
        if (hold) {
            return;
        }
        switch (tableData[rowIndex][cellIndex]) {
            case CODE.OPENED:
            case CODE.FLAG_MINE:
            case CODE.FLAG:
            case CODE.QUESTION:
            case CODE.QUESTION_MINE:
                return;
            case CODE.NORMAL:
                dispatch({ type: OPEN_CELL, row: rowIndex, cell: cellIndex })
                return;
            case CODE.MINE:
                dispatch({ type: CLICK_MINE, row: rowIndex, cell: cellIndex })
                return;
            default:
                break;
        }
    }, [tableData[rowIndex][cellIndex]], hold)

    const onRLMClick = useCallback((e) => {
        e.preventDefault();
        if (hold) {
            return;
        }
        switch (tableData[rowIndex][cellIndex]) {
            case CODE.NORMAL:
            case CODE.MINE:
                dispatch({ type: FLAG_CELL, row: rowIndex, cell: cellIndex })
                return;
            case CODE.FLAG:
            case CODE.FLAG_MINE:
                dispatch({ type: QUESTION_CELL, row: rowIndex, cell: cellIndex })
                return;
            case CODE.QUESTION:
            case CODE.QUESTION_MINE:
                dispatch({ type: NORMAL_CELL, row: rowIndex, cell: cellIndex })
                return;
            default:
                break;
        }
    }, [tableData[rowIndex][cellIndex]], hold)
    return (
        <td
            style={getTdStyle(tableData[rowIndex][cellIndex])}
            onClick={onClickTd}
            onContextMenu={onRLMClick}
        >
            {getTdText(tableData[rowIndex][cellIndex])}
        </td>
    )
}

export default Td
