const hexElement = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'a', 'b', 'c', 'd', 'e', 'f']

function getRandomNumber() {
    return Math.floor(Math.random() * hexElement.length )
}

function btnClickHandler() {
    let hexCode = "#"

    for (let i = 0; i < 6; i++) {
        hexCode = hexCode + hexElement[getRandomNumber()]
    }

    document.querySelector('.content h1 p:last-child').innerHTML = `${hexCode}`
    document.querySelector('body').style.backgroundColor = hexCode
    document.querySelector('.content h1 p:first-child').style.color = hexCode
    document.querySelector('.content h1 p:last-child').style.color = hexCode
}

btnClickHandler()
document.querySelector('.content button').addEventListener('click', btnClickHandler)
