import React from "react";
import ReactDOM from "react-dom/client";

// import ClassFile from "./지뢰찾기/MineSearch";
import ClassFile from "./test";

ReactDOM.createRoot(document.querySelector("#root")).render(<ClassFile />);
