import React, { useState, useEffect, useRef } from "react";

import { useInView } from "react-intersection-observer";



const test = () => {
  const [products, setProducts] = useState([]);
  const [page, setPage] = useState(0); // 현재 페이지 번호 (페이지네이션)
  const [ref, inView] = useInView();

  const getAllPokemon = async ({ pageParam = 0 }) => {
    return await axios.get("https://pokeapi.co/api/v2/pokemon", {
      params: {
        limit: 30,
        offset: pageParam
      }
    })
      .then((res) => res.data)
  }

  useEffect(() => {
    // inView가 true 일때만 실행한다.
    if (inView) {
      console.log(inView, '무한 스크롤 요청 🎃')

      productFetch();
    }
  }, [inView]);



  return (
    <>
      <div>사람</div>
    </>
  );
};

export default test;
